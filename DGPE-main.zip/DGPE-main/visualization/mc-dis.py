import json
import multiprocessing
from collections import defaultdict
import numpy as np
from tqdm import tqdm
import seaborn as sns
from matplotlib import pyplot as plt


# 计算单张图像的MC值
def mc(box_per_image: np.ndarray):
    if len(box_per_image) < 2:
        return None
    num_box = len(box_per_image)
    # 计算相关系数矩阵并求和（减去对角线元素）
    mc_value = (np.abs(np.corrcoef(box_per_image)).sum() - num_box) / (num_box * (num_box - 1))
    return mc_value.item()


# 计算COCO数据集的MC值
def coco_mc(coco_ann: str, process: int = 6):
    # 加载COCO标注文件
    with open(coco_ann, "r") as f:
        ann_dict = json.load(f)

    # 按图像ID分组收集边界框
    bbox_per_image = defaultdict(list)
    for annotation in ann_dict["annotations"]:
        boxes = annotation["bbox"]
        bbox_per_image[annotation["image_id"]].append(boxes)

    # 多进程计算MC值
    with multiprocessing.Pool(processes=process) as pool:
        dataset_mc = list(tqdm(
            pool.imap(mc, bbox_per_image.values()),
            total=len(bbox_per_image),
            desc="Calculating MC"
        ))

    # 过滤无效值（单目标图像的MC为None）
    dataset_mc = [t for t in dataset_mc if t is not None]
    return dataset_mc


# 主函数
if __name__ == "__main__":
    # 指定COCO标注文件路径
    coco_annotation_path = "E:\YYY\data/NWPU/annotations\instances_train2017.json"

    # 计算MC值
    dataset_mc = coco_mc(coco_annotation_path)

    # 绘制分布直方图
    sns.histplot(
        dataset_mc,
        stat="density",
        bins=80,
        kde=True,
        alpha=0.3,























        edgecolor=None,
        label="coco"
    )
    plt.legend()
    plt.xlabel("Macroscopic correlation")
    plt.ylabel("Density of images")
    plt.title("Distribution of MC Score on COCO Dataset")
    plt.grid(True, alpha=0.3)
    plt.tight_layout()
    plt.show()