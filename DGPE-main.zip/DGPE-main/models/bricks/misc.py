"""Enhanced modules inspired by torchvision.ops.misc for compatibility with lower PyTorch versions."""
import warnings
from typing import Callable, List, Optional, Union, Tuple

import torch
from torch import Tensor, nn


class FrozenBatchNorm2d(nn.Module):
    """
    BatchNorm2d with frozen batch statistics and affine parameters during training.
    Suitable for fine-tuning pre-trained models in low-resource scenarios.

    Args:
        num_features (int): Number of features C from input (N, C, H, W)
        eps (float): Added to denominator for numerical stability. Default: 1e-5
        device (torch.device, optional): Target device for buffers. Default: None
        dtype (torch.dtype, optional): Data type for buffers. Default: None

    Example:
        >>> # Load from existing BatchNorm2d
        >>> bn = nn.BatchNorm2d(64)
        >>> fbn = FrozenBatchNorm2d.from_batch_norm(bn)
    """

    def __init__(
            self,
            num_features: int,
            eps: float = 1e-5,
            device: Optional[torch.device] = None,
            dtype: Optional[torch.dtype] = None
    ):
        super().__init__()
        self.eps = eps
        factory_kwargs = {'device': device, 'dtype': dtype}
        self.register_buffer("weight", torch.ones(num_features, **factory_kwargs))
        self.register_buffer("bias", torch.zeros(num_features, **factory_kwargs))
        self.register_buffer("running_mean", torch.zeros(num_features, **factory_kwargs))
        self.register_buffer("running_var", torch.ones(num_features, **factory_kwargs))

    @classmethod
    def from_batch_norm(cls, bn: nn.BatchNorm2d) -> 'FrozenBatchNorm2d':
        """Convert a standard BatchNorm2d to frozen version"""
        fbn = cls(
            num_features=bn.num_features,
            eps=bn.eps,
            device=bn.weight.device,
            dtype=bn.weight.dtype
        )
        fbn.weight.data.copy_(bn.weight.data)
        fbn.bias.data.copy_(bn.bias.data)
        fbn.running_mean.data.copy_(bn.running_mean.data)
        fbn.running_var.data.copy_(bn.running_var.data)
        return fbn

    def _load_from_state_dict(self, state_dict, prefix, *args, **kwargs):
        num_batches_tracked_key = prefix + "num_batches_tracked"
        if num_batches_tracked_key in state_dict:
            del state_dict[num_batches_tracked_key]
        super()._load_from_state_dict(state_dict, prefix, *args, **kwargs)

    def forward(self, x: Tensor) -> Tensor:
        # Fuse operations for better performance
        scale = self.weight * (self.running_var + self.eps).rsqrt()
        bias = self.bias - self.running_mean * scale
        return x * scale[None, :, None, None] + bias[None, :, None, None]

    def __repr__(self) -> str:
        return f"{self.__class__.__name__}({self.weight.shape[0]}, eps={self.eps})"


class ConvNormActivation(nn.Sequential):
    """
    Configurable block for Conv-Norm-Activation pattern with enhanced flexibility.

    Supports:
    - Various padding modes (zeros, reflect, etc.)
    - Custom normalization/activation layers
    - Automatic same padding calculation
    - 2D/3D convolutions via subclassing

    Args:
        in_channels (int): Input channels
        out_channels (int): Output channels
        kernel_size (int): Convolution kernel size. Default: 3
        stride (int): Convolution stride. Default: 1
        padding (Optional[int]): Explicit padding. Default: auto-calculated
        padding_mode (str): Padding strategy. Default: 'zeros'
        groups (int): Connection groups. Default: 1
        norm_layer (Optional[Callable]): Normalization layer. Default: None
        activation_layer (Optional[Callable]): Activation layer. Default: ReLU
        dilation (int): Convolution dilation. Default: 1
        inplace (bool): Activation inplace. Default: True
        bias (Optional[bool]): Conv bias. Default: None (auto-detect)
        conv_layer (Callable): Conv layer type. Default: nn.Conv2d
    """

    def __init__(
            self,
            in_channels: int,
            out_channels: int,
            kernel_size: Union[int, Tuple[int, ...]] = 3,
            stride: Union[int, Tuple[int, ...]] = 1,
            padding: Optional[Union[int, Tuple[int, ...]]] = None,
            padding_mode: str = 'zeros',
            groups: int = 1,
            norm_layer: Optional[Callable[..., nn.Module]] = None,
            activation_layer: Optional[Callable[..., nn.Module]] = nn.ReLU,
            dilation: Union[int, Tuple[int, ...]] = 1,
            inplace: Optional[bool] = True,
            bias: Optional[bool] = None,
            conv_layer: Callable[..., nn.Module] = nn.Conv2d,
    ):
        if padding is None:
            if isinstance(kernel_size, int):
                kernel_size = (kernel_size,) * (conv_layer.ndim if hasattr(conv_layer, 'ndim') else 2)
            padding = tuple((k - 1) // 2 * d for k, d in zip(kernel_size,
                                                             dilation if isinstance(dilation, tuple) else (
                                                                                                          dilation,) * len(
                                                                 kernel_size)))

        if bias is None:
            bias = norm_layer is None

        layers = [
            conv_layer(
                in_channels, out_channels, kernel_size,
                stride=stride,
                padding=padding,
                dilation=dilation,
                groups=groups,
                bias=bias,
                padding_mode=padding_mode
            )
        ]

        if norm_layer is not None:
            layers.append(norm_layer(out_channels))

        if activation_layer is not None:
            activation_params = {} if inplace is None else {"inplace": inplace}
            layers.append(activation_layer(**activation_params))

        super().__init__(*layers)
        self.out_channels = out_channels

    def __repr__(self):
        return f"{self.__class__.__name__}(in={self[0].in_channels}, out={self.out_channels})"


class Conv2dNormActivation(ConvNormActivation):
    """Optimized 2D Conv-Norm-Activation block with default parameters"""

    def __init__(
            self,
            in_channels: int,
            out_channels: int,
            kernel_size: Union[int, Tuple[int, int]] = 3,
            stride: Union[int, Tuple[int, int]] = 1,
            padding: Optional[Union[int, Tuple[int, int]]] = None,
            padding_mode: str = 'zeros',
            groups: int = 1,
            norm_layer: Optional[Callable[..., nn.Module]] = nn.BatchNorm2d,
            activation_layer: Optional[Callable[..., nn.Module]] = nn.ReLU,
            dilation: Union[int, Tuple[int, int]] = 1,
            inplace: bool = True,
            bias: Optional[bool] = None,
    ):
        super().__init__(
            in_channels, out_channels, kernel_size,
            stride=stride,
            padding=padding,
            padding_mode=padding_mode,
            groups=groups,
            norm_layer=norm_layer,
            activation_layer=activation_layer,
            dilation=dilation,
            inplace=inplace,
            bias=bias,
            conv_layer=nn.Conv2d
        )


class SqueezeExcitation(nn.Module):
    """
    Enhanced Squeeze-and-Excitation block with ratio-based channel reduction

    Args:
        input_channels (int): Input feature channels
        squeeze_ratio (float): Channel reduction ratio. Default: 0.25
        squeeze_channels (Optional[int]): Optional explicit squeeze channels
        activation (Callable): Squeeze activation. Default: ReLU
        scale_activation (Callable): Excitation activation. Default: Sigmoid
        spatial_dims (int): 2 for 2D, 3 for 3D data. Default: 2
    """

    def __init__(
            self,
            input_channels: int,
            squeeze_ratio: float = 0.25,
            squeeze_channels: Optional[int] = None,
            activation: Callable = nn.ReLU,
            scale_activation: Callable = nn.Sigmoid,
            spatial_dims: int = 2,
    ):
        super().__init__()
        self.spatial_dims = spatial_dims
        self.input_channels = input_channels
        self.squeeze_ratio = squeeze_ratio

        if squeeze_channels is None:
            squeeze_channels = max(1, int(input_channels * squeeze_ratio))

        if spatial_dims == 2:
            pool = nn.AdaptiveAvgPool2d(1)
            conv = nn.Conv2d
        elif spatial_dims == 3:
            pool = nn.AdaptiveAvgPool3d(1)
            conv = nn.Conv3d
        else:
            raise ValueError(f"Unsupported spatial dimensions: {spatial_dims}")

        self.avgpool = pool
        self.fc1 = conv(input_channels, squeeze_channels, 1)
        self.fc2 = conv(squeeze_channels, input_channels, 1)
        self.activation = activation()
        self.scale_activation = scale_activation()

    def _scale(self, x: Tensor) -> Tensor:
        scale = self.avgpool(x)
        scale = self.fc1(scale)
        scale = self.activation(scale)
        scale = self.fc2(scale)
        return self.scale_activation(scale)

    def forward(self, x: Tensor) -> Tensor:
        return x * self._scale(x)

    def __repr__(self):
        return (f"{self.__class__.__name__}(in={self.input_channels}, "
                f"squeeze={self.squeeze_ratio}, dims={self.spatial_dd}D)")


class MLP(nn.Sequential):
    """
    Enhanced Multi-Layer Perceptron with residual connections

    Args:
        in_dim (int): Input dimension
        hidden_dims (List[int]): Hidden layer dimensions
        norm_layer (Optional[Callable]): Optional normalization after linear layers
        activation (Callable): Activation function. Default: ReLU
        dropout (float): Dropout probability. Default: 0.0
        residual (bool): Enable residual connections. Default: False
        residual_skip (Optional[int]): Apply residual every N layers. Default: None
    """

    def __init__(
            self,
            in_dim: int,
            hidden_dims: List[int],
            norm_layer: Optional[Callable] = None,
            activation: Callable = nn.ReLU,
            dropout: float = 0.0,
            residual: bool = False,
            residual_skip: Optional[int] = None,
    ):
        layers = []
        prev_dim = in_dim
        residual_counter = 0

        for i, dim in enumerate(hidden_dims):
            layers.append(nn.Linear(prev_dim, dim))

            if norm_layer:
                layers.append(norm_layer(dim))

            if i < len(hidden_dims) - 1:  # No activation after last layer
                layers.append(activation())

            if dropout > 0:
                layers.append(nn.Dropout(dropout))

            # Handle residual connections
            if residual and prev_dim == dim:
                if residual_skip is None or (residual_skip and residual_counter % residual_skip == 0):
                    layers = self._add_residual(layers)
                residual_counter += 1

            prev_dim = dim

        super().__init__(*layers)

    def _add_residual(self, layers: List[nn.Module]) -> List[nn.Module]:
        """Wrap last few layers with residual connection"""
        if len(layers) < 2:
            return layers
        *rest, linear, norm = layers[-2:]
        return rest + [ResidualWrapper(nn.Sequential(linear, norm))]


class ResidualWrapper(nn.Module):
    """Adds residual connection around a module"""

    def __init__(self, module: nn.Module):
        super().__init__()
        self.module = module

    def forward(self, x: Tensor) -> Tensor:
        return x + self.module(x)


class Permute(nn.Module):
    """
    Safe tensor dimension permutation with validation

    Args:
        dims (List[int]): Target dimension order
        validate (bool): Check dimension validity. Default: True
    """

    def __init__(self, dims: List[int], validate: bool = True):
        super().__init__()
        self.dims = dims
        self.validate = validate

    def forward(self, x: Tensor) -> Tensor:
        if self.validate:
            if len(self.dims) != x.ndim:
                raise ValueError(f"Permute dims {self.dims} rank mismatch with input {x.shape}")
            if sorted(self.dims) != list(range(x.ndim)):
                raise ValueError(f"Invalid permutation dims {self.dims} for input shape {x.shape}")
        return x.permute(*self.dims)

    def __repr__(self):
        return f"{self.__class__.__name__}(dims={self.dims})"