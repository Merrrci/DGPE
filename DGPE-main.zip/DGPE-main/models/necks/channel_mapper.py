from functools import partial
from typing import List
import torch
from torch import nn
from models.bricks.misc import Conv2dNormActivation


class ChannelMapper(nn.Module):
    def __init__(
            self,
            in_channels: List[int],
            out_channels: int,
            num_outs: int,
            kernel_size: int = 1,
            stride: int = 1,
            groups: int = 1,
            norm_layer=partial(nn.GroupNorm, 32),
            activation_layer: nn.Module = None,
            dilation: int = 1,
            inplace: bool = True,
            bias: bool = None,
            # Attention parameters
            use_attention: bool = True,  # Whether to enable attention
            attn_reduction: int = 4  # Multi-scale compression ratio
    ):
        super().__init__()
        self.in_channels = in_channels
        self.convs = nn.ModuleList()
        self.attentions = nn.ModuleList()
        self.num_channels = [out_channels] * num_outs

        class EMA(nn.Module):
            """Efficient Multi-Scale Attention"""

            def __init__(self, channels: int, reduction: int = 4):
                super().__init__()
                self.reduction = reduction
                self.groups = channels // reduction
                assert channels % reduction == 0, "channels must be divisible by reduction"

                # Multi-branch convolution
                self.conv1 = nn.Conv2d(channels, channels, kernel_size=3, padding=1, groups=self.groups)
                self.conv2 = nn.Conv2d(channels, channels, kernel_size=5, padding=2, groups=self.groups)
                self.conv3 = nn.Conv2d(channels, channels, kernel_size=7, padding=3, groups=self.groups)

                # Channel fusion
                self.fuse = nn.Sequential(
                    nn.Conv2d(3 * channels, channels // reduction, 1),
                    nn.ReLU(inplace=True),
                    nn.Conv2d(channels // reduction, channels, 1),
                    nn.Sigmoid()
                )
                # Initialization
                self._init_weights()

            def _init_weights(self):
                for m in self.modules():
                    if isinstance(m, nn.Conv2d):
                        nn.init.kaiming_normal_(m.weight, mode='fan_out', nonlinearity='relu')
                        if m.bias is not None:
                            nn.init.constant_(m.bias, 0)

            def forward(self, x: torch.Tensor) -> torch.Tensor:
                # Multi-scale branches
                x1 = self.conv1(x)
                x2 = self.conv2(x)
                x3 = self.conv3(x)

                # Concatenate and fuse
                fused = torch.cat([x1, x2, x3], dim=1)
                weights = self.fuse(fused)

                # Weighted fusion
                return x * weights

        # --------------------------------------------------------- #

        # Convolutional layers and attention modules
        for in_ch in in_channels:
            # Main convolution layer
            self.convs.append(
                Conv2dNormActivation(
                    in_channels=in_ch,
                    out_channels=out_channels,
                    kernel_size=kernel_size,
                    stride=stride,
                    padding=(kernel_size - 1) // 2,
                    bias=bias,
                    groups=groups,
                    dilation=dilation,
                    norm_layer=norm_layer,
                    activation_layer=activation_layer,
                    inplace=inplace,
                )
            )
            # Attention module
            if use_attention:
                self.attentions.append(EMA(out_channels, attn_reduction))
            else:
                self.attentions.append(nn.Identity())

        # Additional downsampling layers
        for _ in range(num_outs - len(in_channels)):
            self.convs.append(
                Conv2dNormActivation(
                    in_channels=out_channels,
                    out_channels=out_channels,
                    kernel_size=3,
                    stride=2,
                    padding=1,
                    bias=bias,
                    groups=groups,
                    dilation=dilation,
                    norm_layer=norm_layer,
                    activation_layer=activation_layer,
                    inplace=inplace,
                )
            )
            # Attention module
            if use_attention:
                self.attentions.append(EMA(out_channels, attn_reduction))
            else:
                self.attentions.append(nn.Identity())

        self.init_weights()

    def init_weights(self):
        """Initialize convolution layer weights"""
        for layer in self.modules():
            if isinstance(layer, nn.Conv2d):
                nn.init.xavier_uniform_(layer.weight, gain=1)
                if layer.bias is not None:
                    nn.init.constant_(layer.bias, 0)

    def forward(self, inputs):
        """Forward pass"""
        inputs = list(inputs.values())
        assert len(inputs) <= len(self.in_channels)

        # Determine starting index
        start = len(self.in_channels) - len(inputs)
        convs = self.convs[start:]
        attns = self.attentions[start:]

        # Process input features
        outs = []
        for i in range(len(inputs)):
            x = convs[i](inputs[i])  # Convolution
            x = x + attns[i](x)  # Residual connection + EMA attention
            outs.append(x)

        # Process additional downsampling layers
        for i in range(len(inputs), len(convs)):
            if i == len(inputs):
                x = convs[i](outs[-1])
            else:
                x = convs[i](outs[-1])
            x = x + attns[i](x)
            outs.append(x)

        return outs